let cart = [];

function addToCart(name, price) {
  cart.push({ name, price });
  alert(`${name} added to cart!`);
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart-items');
  const total = document.getElementById('cart-total');
  if (!cartList || !total) return;

  cartList.innerHTML = '';
  let sum = 0;
  cart.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.name} - ₹${item.price}`;
    cartList.appendChild(li);
    sum += item.price;
  });
  total.textContent = sum;
}
